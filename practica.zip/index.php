<?php 
 $p = 'Ассалам Алейкум!';
?>

<?php 
 $name = 'Александр';
 $surname = 'Лебедев';
 $city = 'Москва';
 $age = 22;
?>


<?php
include 'main.php';
?>