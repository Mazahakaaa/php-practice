<div class="footer">
            <h2>Привет, Гамид!</h2>
        </div>